export const COUNTRIES = [
  "Australia",
  "Brazil",
  "Canada",
  "France",
  "Germany",
  "India",
  "Japan",
  "Perú",
  "South Africa",
  "United Kingdom",
  "United States",
];
